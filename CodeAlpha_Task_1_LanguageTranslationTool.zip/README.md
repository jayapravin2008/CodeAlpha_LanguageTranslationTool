# CodeAlpha Task 1 - Language Translation Tool

A simple web-based language translation tool developed for the CodeAlpha Artificial Intelligence Internship Task 1.

## Features
- Enter text to translate
- Select source language
- Select target language
- Automatic source-language detection
- Translation using Google Translate through `deep-translator`
- Copy translated text
- Responsive web interface

## Technologies
- Python
- Flask
- HTML
- CSS
- JavaScript
- deep-translator

## Installation

1. Open a terminal in this project folder.
2. Install dependencies:

```bash
pip install -r requirements.txt
```

3. Start the application:

```bash
python app.py
```

4. Open:

```text
http://127.0.0.1:5000
```

## Note
An internet connection is required because the translation service is accessed online.
