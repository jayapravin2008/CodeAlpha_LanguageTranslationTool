from deep_translator import GoogleTranslator

def translate_text(text, source, target):
    # "auto" lets the translation service detect the source language.
    translator = GoogleTranslator(source=source, target=target)
    return translator.translate(text)
